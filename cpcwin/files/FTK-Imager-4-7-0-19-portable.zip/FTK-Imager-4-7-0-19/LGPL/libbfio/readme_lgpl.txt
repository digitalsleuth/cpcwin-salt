libbfio is licensed under LGPL; here is a link to the source code: 
https://github.com/libyal/libbfio/releases/download/20191230/libbfio-alpha-20191230.tar.gz 
