libvshadow is licensed under LGPL; here is a link to the source code: 
https://github.com/libyal/libvshadow/releases/download/20191221/libvshadow-alpha-20191221.tar.gz 
